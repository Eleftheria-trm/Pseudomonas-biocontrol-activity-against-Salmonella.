#!/usr/bin/env Rscript

# KEGG GSEA for Pseudomonas lactis PK307-4
# Reference: Pseudomonas fluorescens SBW25 (KEGG: pfs)
#
# Required input files:
#   1. Differential expression CSV:
#      locus_tag, gene_name, logFC, Pvalue, q.value
#   2. lactis_to_pfs_kegg_mapping.csv
#      locus_tag, lactis_id, kegg_id, ...
#
# Run:
#   Rscript run_kegg_gsea.R differential_expression.csv
#
# Packages:
#   clusterProfiler, dplyr, tidyr, ggplot2

suppressPackageStartupMessages({
  library(clusterProfiler)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
})

# ============================================================
# 1. Configuration
# ============================================================

args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 1) {
  stop("Usage: Rscript run_kegg_gsea.R differential_expression.csv")
}

de_file <- args[1]
mapping_file <- "PK0307_to_pfs_kegg_mapping.csv"
outdir <- "gsea_pfs"

organism <- "pfs"
min_gs_size <- 3
max_gs_size <- 800
seed <- 42

dir.create(outdir, recursive = TRUE, showWarnings = FALSE)

# ============================================================
# 2. Read input files
# ============================================================

de <- read.csv(de_file, check.names = FALSE)
mapping <- read.csv(mapping_file, check.names = FALSE)

required_de <- c("locus_tag", "logFC")
required_map <- c("locus_tag", "kegg_id")

stopifnot(all(required_de %in% names(de)))
stopifnot(all(required_map %in% names(mapping)))

# Optional columns
for (col in c("gene_name", "Pvalue", "q.value")) {
  if (!col %in% names(de)) {
    de[[col]] <- NA
  }
}

# ============================================================
# 3. Prepare and validate mapping
# ============================================================

de <- de %>%
  mutate(
    locus_tag = trimws(as.character(locus_tag)),
    logFC = as.numeric(logFC)
  )

mapping <- mapping %>%
  mutate(
    locus_tag = trimws(as.character(locus_tag)),
    kegg_id = sub("^pfs:", "", trimws(as.character(kegg_id)))
  ) %>%
  filter(
    !is.na(locus_tag),
    locus_tag != "",
    !is.na(kegg_id),
    kegg_id != ""
  ) %>%
  distinct(locus_tag, kegg_id)

# Avoid ambiguous locus-tag mappings
ambiguous_loci <- mapping %>%
  count(locus_tag) %>%
  filter(n > 1)

if (nrow(ambiguous_loci) > 0) {
  warning(nrow(ambiguous_loci),
          " locus tags map to multiple KEGG genes; excluding them.")
  
  mapping <- mapping %>%
    filter(!locus_tag %in% ambiguous_loci$locus_tag)
}

# Check expression identifiers
if (anyDuplicated(de$locus_tag)) {
  stop("Duplicate locus_tag values in differential expression input.")
}

# ============================================================
# 4. Join differential expression and KEGG mapping
# ============================================================

mapped <- de %>%
  inner_join(mapping, by = "locus_tag") %>%
  filter(is.finite(logFC))

# One KEGG ID may map to multiple locus tags.
# Keep the gene with the largest absolute logFC.
duplicates <- mapped %>%
  count(kegg_id) %>%
  filter(n > 1)

if (nrow(duplicates) > 0) {
  message("Resolving ", nrow(duplicates),
          " duplicated KEGG identifiers.")
}

mapped_unique <- mapped %>%
  arrange(desc(abs(logFC)), locus_tag) %>%
  distinct(kegg_id, .keep_all = TRUE)

# ============================================================
# 5. Mapping diagnostics
# ============================================================

n_tested <- n_distinct(de$locus_tag[is.finite(de$logFC)])
n_mapped_loci <- n_distinct(mapped$locus_tag)
n_kegg <- nrow(mapped_unique)

coverage <- 100 * n_mapped_loci / n_tested

cat("\n========== MAPPING SUMMARY ==========\n")
cat("Tested genes:           ", n_tested, "\n")
cat("Mapped locus tags:      ", n_mapped_loci, "\n")
cat("Unique KEGG genes:      ", n_kegg, "\n")
cat("Mapping coverage:       ", round(coverage, 2), "%\n")
cat("=====================================\n\n")

write.csv(
  mapped_unique,
  file.path(outdir, "mapped_genes.csv"),
  row.names = FALSE
)

write.csv(
  de %>% filter(!locus_tag %in% mapped$locus_tag),
  file.path(outdir, "unmapped_genes.csv"),
  row.names = FALSE
)

# ============================================================
# 6. Construct ranked gene list
# ============================================================

# Ranking statistic: signed log2 fold change.
# Positive NES = enrichment toward positive logFC.
# Negative NES = enrichment toward negative logFC.

gene_list <- mapped_unique$logFC
names(gene_list) <- mapped_unique$kegg_id

gene_list <- sort(gene_list, decreasing = TRUE)

stopifnot(
  !anyNA(gene_list),
  !anyDuplicated(names(gene_list)),
  length(gene_list) > 0
)

write.csv(
  data.frame(
    kegg_id = names(gene_list),
    logFC = unname(gene_list)
  ),
  file.path(outdir, "ranked_gene_list.csv"),
  row.names = FALSE
)

# ============================================================
# 7. Run KEGG GSEA
# ============================================================

set.seed(seed)

gsea <- gseKEGG(
  geneList = gene_list,
  organism = organism,
  keyType = "kegg",
  minGSSize = min_gs_size,
  maxGSSize = max_gs_size,
  pvalueCutoff = 1,
  pAdjustMethod = "BH",
  eps = 1e-10,
  seed = TRUE,
  verbose = FALSE
)

if (is.null(gsea)) {
  stop("GSEA returned NULL. Check KEGG identifier mapping.")
}

results <- as.data.frame(gsea) %>%
  arrange(p.adjust)

write.csv(
  results,
  file.path(outdir, "gsea_all_pathways.csv"),
  row.names = FALSE
)

significant <- results %>%
  filter(!is.na(p.adjust), p.adjust < 0.05)

write.csv(
  significant,
  file.path(outdir, "gsea_significant_pathways.csv"),
  row.names = FALSE
)

cat("\n========== GSEA SUMMARY ==========\n")
cat("Pathways tested:        ", nrow(results), "\n")
cat("Significant (BH < 0.05):", nrow(significant), "\n")
cat("==================================\n\n")

print(
  results %>%
    select(ID, Description, setSize, NES, pvalue, p.adjust) %>%
    head(20),
  row.names = FALSE
)

# ============================================================
# 8. Extract leading-edge genes
# ============================================================

if (nrow(significant) > 0) {
  
  leading_edges <- significant %>%
    select(ID, Description, NES, p.adjust, core_enrichment) %>%
    separate_rows(core_enrichment, sep = "/") %>%
    rename(kegg_id = core_enrichment) %>%
    left_join(
      mapped_unique %>%
        select(kegg_id, locus_tag, gene_name,
               logFC, Pvalue, q.value),
      by = "kegg_id"
    ) %>%
    arrange(p.adjust, Description, desc(abs(logFC)))
  
  write.csv(
    leading_edges,
    file.path(outdir, "gsea_leading_edge_genes.csv"),
    row.names = FALSE
  )
  
  leading_edge_summary <- leading_edges %>%
    count(ID, Description, name = "leading_edge_genes") %>%
    left_join(
      significant %>%
        select(ID, setSize, NES, p.adjust),
      by = "ID"
    ) %>%
    mutate(
      leading_edge_percent =
        round(100 * leading_edge_genes / setSize, 1)
    ) %>%
    arrange(p.adjust)
  
  write.csv(
    leading_edge_summary,
    file.path(outdir, "gsea_leading_edge_summary.csv"),
    row.names = FALSE
  )
}

# ============================================================
# 9. Plot significant pathways
# ============================================================

if (nrow(significant) > 0) {
  
  plot_data <- significant %>%
    mutate(
      Description = factor(
        Description,
        levels = Description[order(NES)]
      ),
      direction = ifelse(NES > 0, "Positive", "Negative")
    )
  
  p <- ggplot(
    plot_data,
    aes(x = NES, y = Description, fill = direction)
  ) +
    geom_col(width = 0.7) +
    scale_fill_manual(
      values = c(
        "Positive" = "#2878B5",
        "Negative" = "#D65A4A"
      )
    ) +
    labs(
      title = "KEGG GSEA — P. lactis vs SBW25 reference",
      subtitle = "Significant pathways (BH-adjusted p < 0.05)",
      x = "Normalized enrichment score (NES)",
      y = NULL,
      fill = "Enrichment"
    ) +
    theme_bw(base_size = 12) +
    theme(
      panel.grid.major.y = element_blank(),
      legend.position = "bottom"
    )
  
  ggsave(
    file.path(outdir, "gsea_significant_pathways.pdf"),
    p,
    width = 10,
    height = max(5, 0.4 * nrow(significant) + 2)
  )
}

# ============================================================
# 10. Save reproducibility information
# ============================================================

writeLines(
  capture.output(sessionInfo()),
  file.path(outdir, "session_info.txt")
)

saveRDS(
  gsea,
  file.path(outdir, "gsea_result.rds")
)

cat("\nAnalysis complete. Results saved to:", outdir, "\n")