library(dplyr)



mapping <- read.csv("lactis_to_sbw25_mapping.csv")
input <- read.csv("differential_expression.csv") #replaced by plant_2_25.csv or invitro_2_25.csv


# Read GFF CDS features
read_cds <- function(file) {
  gff <- read.delim(
    file,
    comment.char = "#",
    header = FALSE,
    sep = "\t",
    quote = "",
    fill = TRUE,
    col.names = c(
      "contig", "source", "type", "start", "end",
      "score", "strand", "phase", "attributes"
    )
  )
  
  gff %>% filter(type == "CDS")
}

prokka <- read_cds("PS18PK-0307-4-prokka.gff")
prodigal <- read_cds("PS18PK-0307-4-contigs.fasta.gff")

# Extract Prokka locus tags
prokka <- prokka %>%
  mutate(
    locus_tag = sub(
      ".*(?:^|;)locus_tag=([^;]+).*",
      "\\1",
      attributes,
      perl = TRUE
    )
  )

# Extract Prodigal IDs and reconstruct FASTA IDs
prodigal <- prodigal %>%
  mutate(
    prodigal_id = sub(
      ".*(?:^|;)ID=([^;]+).*",
      "\\1",
      attributes,
      perl = TRUE
    ),
    lactis_id = paste0(
      contig, "_",
      sub("^.*_", "", prodigal_id)
    )
  )

# Exact coordinate matching
coordinate_map <- prokka %>%
  select(locus_tag, contig, start, end, strand) %>%
  inner_join(
    prodigal %>%
      select(lactis_id, contig, start, end, strand),
    by = c("contig", "start", "end", "strand")
  )

cat("Prokka CDS:", nrow(prokka), "\n")
cat("Prodigal CDS:", nrow(prodigal), "\n")
cat("Coordinate matches:", nrow(coordinate_map), "\n")

# Join with your existing DIAMOND RBH mapping
full_mapping <- coordinate_map %>%
  inner_join(
    mapping,
    by = "lactis_id"
  )

cat("Locus tags mapped to KEGG:",
    nrow(full_mapping), "\n")

write.csv(
  full_mapping,
  "PK0307_to_pfs_kegg_mapping.csv",
  row.names = FALSE
)

#Check mapping coverage

mapped_input <- input %>%
  inner_join(
    full_mapping,
    by = "locus_tag"
  )

cat("Original tested genes:", nrow(input), "\n")
cat("Mapped tested genes:",
    n_distinct(mapped_input$locus_tag), "\n")

cat("Mapping coverage:",
    round(
      100 * n_distinct(mapped_input$locus_tag) /
        n_distinct(input$locus_tag),
      2
    ),
    "%\n"
)

gene_list <- mapped_input %>%
  filter(!is.na(logFC), !is.na(kegg_id)) %>%
  arrange(desc(abs(logFC))) %>%
  distinct(kegg_id, .keep_all = TRUE) %>%
  arrange(desc(logFC)) %>%
  {
    setNames(.$logFC, .$kegg_id)
  }

length(gene_list)
# Remove KEGG organism prefix
names(gene_list) <- sub("^pfs:", "", names(gene_list))

# Check
head(names(gene_list))
length(gene_list)


library(clusterProfiler)

gsea <- gseKEGG(
  geneList = gene_list,
  organism = "pfs",
  keyType = "kegg",
  minGSSize = 3,
  maxGSSize = 800,
  pvalueCutoff = 1,
  pAdjustMethod = "BH",
  verbose = TRUE
)

write.csv(gsea, paste0("KEGG_Pflourescence.csv"))

