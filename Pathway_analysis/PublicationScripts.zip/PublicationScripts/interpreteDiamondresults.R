library(dplyr)

cols <- c(
  "query", "subject", "identity", "length",
  "qlen", "slen", "evalue", "bitscore"
)

forward <- read.delim(
  "lactis_vs_sbw25.tsv",
  header = FALSE,
  col.names = cols
)

reverse <- read.delim(
  "sbw25_vs_lactis.tsv",
  header = FALSE,
  col.names = cols
)

# Select the highest-scoring hit per query.
# Retain the unfiltered best hit before applying thresholds.
best_hit <- function(df) {
  df %>%
    arrange(query, desc(bitscore), evalue, subject) %>%
    distinct(query, .keep_all = TRUE)
}

fwd_best <- best_hit(forward)
rev_best <- best_hit(reverse)

# Identify reciprocal pairs
rbh <- fwd_best %>%
  inner_join(
    rev_best %>%
      select(
        lactis_id = subject,
        sbw25_id = query
      ),
    by = c(
      "query" = "lactis_id",
      "subject" = "sbw25_id"
    )
  )

# Apply conservative sequence similarity thresholds
rbh_filtered <- rbh %>%
  filter(
    identity >= 30,
    length / qlen >= 0.70,
    length / slen >= 0.70
  )

cat("Forward best hits:", nrow(fwd_best), "\n")
cat("Reverse best hits:", nrow(rev_best), "\n")
cat("Reciprocal best hits:", nrow(rbh), "\n")
cat("Filtered reciprocal hits:", nrow(rbh_filtered), "\n")

# Save the mapping
mapping <- rbh_filtered %>%
  transmute(
    lactis_id = query,
    kegg_id = subject,
    identity,
    coverage_lactis = length / qlen,
    coverage_sbw25 = length / slen,
    bitscore
  )

write.csv(
  mapping,
  "lactis_to_sbw25_mapping.csv",
  row.names = FALSE
)




