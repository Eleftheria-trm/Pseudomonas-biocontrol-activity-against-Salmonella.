#!/usr/bin/env bash

diamond makedb --in SBW25.faa -d sbw25
diamond makedb --in PS18PK-0307-4-contigs.fasta_prot.fasta -d lactis

diamond blastp \
  --query PS18PK-0307-4-contigs.fasta_prot.fasta \
  --db sbw25 \
  --out lactis_vs_sbw25.tsv \
  --threads 4 \
  --evalue 1e-5 \
  --max-target-seqs 10 \
  --outfmt 6 qseqid sseqid pident length qlen slen evalue bitscore

diamond blastp \
  --query SBW25.faa \
  --db lactis \
  --out sbw25_vs_lactis.tsv \
  --threads 4 \
  --evalue 1e-5 \
  --max-target-seqs 10 \
  --outfmt 6 qseqid sseqid pident length qlen slen evalue bitscore
