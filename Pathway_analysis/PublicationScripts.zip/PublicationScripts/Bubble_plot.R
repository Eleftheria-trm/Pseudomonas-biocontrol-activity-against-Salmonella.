
library(ggplot2)
library(dplyr)

input_file <- "gsea_all_pathways.csv"
output_file <- "gsea_bubble_plot.pdf"

padj_cutoff <- 0.05
max_pathways <- 20

gsea <- read.csv(input_file, check.names = FALSE)

# Filter and prepare data
plot_data <- gsea %>%
  filter(
    !is.na(p.adjust),
    !is.na(NES),
    p.adjust < padj_cutoff
  ) %>%
  arrange(p.adjust) %>%
  slice_head(n = max_pathways) %>%
  mutate(
    Description = factor(
      Description,
      levels = Description[order(NES)]
    ),
    significance = -log10(pmax(p.adjust, 1e-300))
  )


p <- ggplot(
  plot_data,
  aes(
    x = NES,
    y = Description,
    size = setSize,
    colour = significance
  )
) +
  geom_vline(
    xintercept = 0,
    linetype = "dashed",
    colour = "grey70"
  ) +
  geom_point(alpha = 0.9) +
  scale_size_continuous(
    name = "Gene set size",
    range = c(3, 10)
  ) +
  scale_colour_gradient(
    low = "#77B5D9",
    high = "#C62828",
    name = expression(-log[10]("Adjusted p-value"))
  ) +
  labs(
    title = "KEGG Gene Set Enrichment Analysis",
    x = "Normalised enrichment score (NES)",
    y = NULL
  ) +
  theme_bw(base_size = 12) +
  theme(
    panel.grid.major.y = element_blank(),
    panel.grid.minor = element_blank(),
    plot.title = element_text(face = "bold", size = 14),
    axis.text.y = element_text(size = 10),
    legend.position = "right"
  )

plot_height <- max(5, 0.38 * nrow(plot_data) + 2)

ggsave(
  output_file,
  plot = p,
  width = 11,
  height = plot_height,
  units = "in"
)

ggsave(
  sub("\\.pdf$", ".png", output_file),
  plot = p,
  width = 11,
  height = plot_height,
  units = "in",
  dpi = 300
)

print(p)
